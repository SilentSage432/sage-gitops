# SOPS + age secrets (Arc Rho)

This directory contains SOPS-encrypted secrets for the SAGE Federation.

## 🔐 Encryption Setup

### 1) Generate age key
```bash
age-keygen -o age.key
# Public part:
grep -m1 '^# public key:' -A1 age.key | tail -1 > .sops.pubkey
```

### 2) Create Flux SOPS secret (Talos/Flux reads private key)
```bash
# Edit namespace if your flux-system is different
kubectl -n flux-system create secret generic sops-age \
  --from-file=age.agekey=./age.key
```

### 3) Put private key in GitHub Actions too (for CI rotations)
Repo Settings → Secrets and variables → Actions:
- `SOPS_AGE_KEY` = (contents of age.key)

### 4) Encrypt a secret file (example)
```bash
# Create plaintext template:
cat > secrets/arc-kappa-db.enc.yaml <<'PLAINTEXT'
apiVersion: v1
kind: Secret
metadata:
  name: kappa-db
  namespace: arc-kappa
type: Opaque
stringData:
  PGPASSWORD: "CHANGE_ME"
  OMICRON_PGHOST: "kappa-postgres.arc-kappa.svc.cluster.local"
PLAINTEXT

# Encrypt with SOPS using your public key (from .sops.pubkey)
sops --encrypt --age "$(cat .sops.pubkey)" --in-place secrets/arc-kappa-db.enc.yaml
```

### 5) Apply with Flux (SOPS will decrypt in cluster)
Flux will reconcile automatically; for kubectl direct:
```bash
kubectl apply -f secrets/arc-kappa-db.enc.yaml
```

## 📁 Secret Files

- `arc-kappa-db.enc.yaml` - Database credentials for Kappa/Postgres
- `ghcr-pull.enc.yaml` - GitHub Container Registry pull credentials
- `cloudflare.enc.yaml` - Cloudflare Tunnel token and configuration

## 🔧 SOPS Configuration

SOPS will automatically use the age key from:
1. Flux system secret (`sops-age` in `flux-system` namespace)
2. GitHub Actions secret (`SOPS_AGE_KEY`)

## 🚨 Security Notes

- Never commit unencrypted secrets
- Rotate age keys periodically
- Use separate keys for different environments
- Monitor secret access in audit logs
